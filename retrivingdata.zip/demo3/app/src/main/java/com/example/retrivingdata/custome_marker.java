package com.example.retrivingdata;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

public class custome_marker implements GoogleMap.InfoWindowAdapter {
   private View view;
   private Context context;

    public custome_marker(View context) {
        context = context;



        context= LayoutInflater.from(context).inflate(R.layout.coustume, null);
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        return null;
    }
}
